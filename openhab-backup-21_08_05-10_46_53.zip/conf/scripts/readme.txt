Your scripts go here.
All script files have to have the ".script" file extension and must follow a special syntax.

Check out the openHAB documentation for more details:
https://www.openhab.org/docs/configuration/rules-dsl.html#scripts
